# Connect to dynamoDB called music and retrieve all the data from the table

import boto3
import json

dynamodb = boto3.resource('dynamodb')
TABLE_NAME = 'music'

def lambda_handler(event, context):
    if event['httpMethod'] == 'GET':
        if event['path'] == '/home':
            return handle_get_songs()
        else:
            return {
                'statusCode': 404,
                'body': json.dumps('Invalid path.')
            }
    else:
        return {
            'statusCode': 400,
            'body': json.dumps('Invalid httpMethod.')
        }

def handle_get_songs():
    table = dynamodb.Table(TABLE_NAME)
    response = table.scan()
    return {
        'statusCode': 200,
        'body': json.dumps(response['Items'])
    }